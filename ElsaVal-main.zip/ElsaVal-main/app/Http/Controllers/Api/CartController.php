<?php

namespace App\Http\Controllers\Api;

use App\Enums\CartStatus;
use App\Http\Controllers\Controller;
use App\Http\Resources\CartResource;
use App\Models\Cart;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class CartController extends Controller
{
    public function index(): AnonymousResourceCollection
    {
        return CartResource::collection(Cart::all());
    }

    public function store(Request $request): CartResource
    {
        $validated = $request->validate([
            'client_id' => ['required', 'exists:clients,id'],
        ]);

        $validated['status'] = CartStatus::Active;

        return new CartResource(Cart::create($validated));
    }

    public function show(Cart $cart): CartResource
    {
        return new CartResource($cart);
    }

    public function update(Request $request, Cart $cart): CartResource
    {
        $data = $request->validate([
            'client_id' => ['required', 'exists:clients, id'],
            'status' => ['required'],
        ]);

        $cart->update($data);

        return new CartResource($cart);
    }

    public function destroy(Cart $cart): JsonResponse
    {
        $cart->delete();

        return response()->json([
            'message' => 'Cart deleted successfully',
        ]);
    }
}
