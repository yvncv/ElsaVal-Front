<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\CartItemResource;
use App\Models\CartItem;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class CartItemController extends Controller
{
    public function index(): AnonymousResourceCollection
    {
        return CartItemResource::collection(CartItem::all());
    }

    public function store(Request $request): CartItemResource
    {
        $validated = $request->validate([
            'cart_id' => ['required', 'exists:carts,id'],
            'product_id' => ['required', 'exists:products,id'],
            'quantity' => ['required', 'integer'],
            'price' => ['required', 'numeric'],
            'total' => ['required', 'numeric'],
        ]);

        return (new CartItemResource(CartItem::create($validated)))->additional([
            'message' => 'Cart item created successfully',
        ]);
    }

    public function show(CartItem $cartItem): CartItemResource
    {
        return new CartItemResource($cartItem);
    }

    public function update(Request $request, CartItem $cartItem): CartItemResource
    {
        $validated = $request->validate([
            'product_id' => ['required', 'exists:products,id'],
            'quantity' => ['required', 'integer'],
            'price' => ['required', 'numeric'],
            'total' => ['required', 'numeric'],
        ]);

        $cartItem->update($validated);

        return (new CartItemResource($cartItem))->additional([
            'message' => 'Cart item updated successfully',
        ]);
    }

    public function destroy(CartItem $cartItem): JsonResponse
    {
        $cartItem->delete();

        return response()->json([
            'message' => 'Cart item deleted successfully',
        ]);
    }
}
