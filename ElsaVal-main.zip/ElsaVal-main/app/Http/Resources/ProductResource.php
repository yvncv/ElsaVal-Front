<?php

namespace App\Http\Resources;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin Product */
class ProductResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'description' => $this->description,
            'images' => $this->getMedia()->map(fn($image) => $image->getFullUrl())->toArray(),
            'cost_price' => $this->cost_price,
            'price' => $this->price,
            'discount' => $this->discount,
            'sku' => $this->sku,
            'stock' => $this->stock,
            'status' => $this->status,
            'category' => new CategoryResource($this->whenLoaded('category')),
            'material' => new MaterialResource($this->whenLoaded('material')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
