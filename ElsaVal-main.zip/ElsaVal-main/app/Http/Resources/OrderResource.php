<?php

namespace App\Http\Resources;

use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin Order */
class OrderResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'client' => new ClientResource($this->whenLoaded('client')),
            'identifier' => $this->identifier,
            'uuid' => $this->uuid,
            'subtotal_price' => $this->subtotal_price,
            'delivery_price' => $this->delivery_price,
            'discount' => $this->discount,
            'total_price' => $this->total_price,
            'street_address' => $this->street_address,
            'status' => $this->status,
            'products' => OrderProductResource::collection($this->whenLoaded('orderProducts')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
