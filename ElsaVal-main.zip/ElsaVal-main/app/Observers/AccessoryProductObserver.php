<?php

namespace App\Observers;

use App\Models\AccessoryProduct;

class AccessoryProductObserver
{
    public function created(AccessoryProduct $accessoryProduct): void
    {
        $accessoryProduct->accessory()->decrement('quantity', $accessoryProduct->quantity * $accessoryProduct->product->stock);
    }
}
