<?php

namespace App\Observers;

use App\Models\Product;

class ProductObserver
{
    public function created(Product $product): void
    {
        $product->material->decrement('quantity', $product->material_weight * $product->stock);
    }

    public function deleting(Product $product): void
    {
        if ($product->accessories()->exists()) {
            $product->accessories()->detach();
        }
    }
}
