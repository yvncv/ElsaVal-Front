<?php

namespace App\Filament\Resources\AccessoryResource\RelationManagers;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Model;

class AccessoryPurchasesRelationManager extends RelationManager
{
    protected static string $relationship = 'accessoryPurchases';

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('quantity')
                    ->label(__('Quantity'))
                    ->numeric()
                    ->integer()
                    ->minValue(1)
                    ->required(),
                TextInput::make('total_price')
                    ->label(__('Total Price'))
                    ->numeric()
                    ->inputMode('decimal')
                    ->minValue(0.01)
                    ->required(),
                Select::make('provider_id')
                    ->label(__('Provider'))
                    ->relationship('provider', 'name')
                    ->required(),

            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('accessory_id')
            ->columns([
                Tables\Columns\TextColumn::make('quantity')
                    ->label('Quantity'),
                Tables\Columns\TextColumn::make('total_price')
                    ->label('Total Price'),
                Tables\Columns\TextColumn::make('provider.name')
                    ->label('Provider'),
                Tables\Columns\TextColumn::make('created_at')
                    ->label('Created At')
                    ->date('d/m/Y h:i:s A'),
            ])
            ->filters([
                //
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()
                    ->label(__('Add Purchase'))
                    ->after(function (Model $record) {
                        $record->accessory()->increment('quantity', $record->quantity);
                        $record->accessory()->update([
                            'unit_price' => $record->accessory->accessoryPurchases()->sum('total_price')
                                / $record->accessory->accessoryPurchases()->sum('quantity'),
                        ]);
                    }),
            ])
            ->actions([
                Tables\Actions\EditAction::make()
                    ->visible(fn (Model $record) => $record->created_at->isToday())
                    ->before(function (EditAction $action, Model $record, array $data) {
                        $newQuantity = $data['quantity'] - $record->quantity;
                        if ($record->accessory->quantity + $newQuantity <= 0) {
                            Notification::make()
                                ->warning()
                                ->title('Acción no permitida')
                                ->body('La cantidad de accesorios no puede ser menor o igual a 0.')
                                ->send();

                            $action->halt();
                        }
                    })
                    ->using(function (Model $record, array $data): Model {
                        $newQuantity = $data['quantity'] - $record->quantity;
                        $record->update(['quantity' => $data['quantity']]);
                        $record->accessory()->increment('quantity', $newQuantity);

                        return $record;
                    }),
                Tables\Actions\DeleteAction::make()
                    ->after(function (Model $record) {
                        $record->accessory()->decrement('quantity', $record->quantity);
                        $record->accessory()->update([
                            'unit_price' => $record->accessory->accessoryPurchases()->sum('total_price')
                                / $record->accessory->accessoryPurchases()->sum('quantity'),
                        ]);
                    }),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('created_at', 'desc');
    }
}
