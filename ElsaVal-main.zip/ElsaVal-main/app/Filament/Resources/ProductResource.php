<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProductResource\Pages;
use App\Models\Accessory;
use App\Models\Material;
use App\Models\Product;
use Filament\Forms\Components\Fieldset;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\SpatieMediaLibraryFileUpload;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Filament\Forms\Get;
use Filament\Forms\Set;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\SpatieMediaLibraryImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Number;
use Illuminate\Support\Str;

class ProductResource extends Resource
{
    protected static ?string $model = Product::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Fieldset::make('Product Information')
                    ->label(__('Product Information'))
                    ->schema([
                        TextInput::make('name')
                            ->label(__('Name'))
                            ->unique(table: Product::class, ignoreRecord: true)
                            ->required(),
                        Select::make('category_id')
                            ->label(__('Category'))
                            ->relationship('category', 'name')
                            ->required(),
                        Textarea::make('description')
                            ->label(__('Description'))
                            ->required(),
                    ]),
                Fieldset::make('Material')
                    ->schema([
                        Select::make('material_id')
                            ->label(__('Material'))
                            ->relationship('material', 'name', modifyQueryUsing: function ($query) {
                                return $query->where('quantity', '>', 0);
                            })
                            ->searchable()
                            ->preload()
                            ->getOptionLabelFromRecordUsing(fn (Model $record
                            ) => "{$record->name} - S/. {$record->unit_price} por gramo - Stock: {$record->quantity} gramos")
                            ->live()
                            ->required(),
                        TextInput::make('material_weight')
                            ->label(__('Material Weight'))
                            ->integer()
                            ->suffix('grams')
                            ->lte(function (Get $get) {
                                return Material::find($get('material_id'))->quantity ?? 0;
                            }, true)
                            ->live()
                            ->afterStateUpdated(function (Set $set, Get $get, HasForms $livewire, TextInput $component) {
                                $livewire->validateOnly($component->getStatePath());
                                self::updatePriceCost($get, $set);
                            })
                            ->required(),
                    ]),
                Fieldset::make('Accessories')
                    ->label(__('Accessories'))
                    ->schema([
                        Repeater::make('productAccessories')
                            ->label(__('Accessories'))
                            ->relationship()
                            ->schema([
                                Select::make('accessory_id')
                                    ->label(__('Accessory'))
                                    ->relationship('accessory', 'name', modifyQueryUsing: function ($query) {
                                        return $query->where('quantity', '>', 0);
                                    })
                                    ->searchable()
                                    ->preload()
                                    ->getOptionLabelFromRecordUsing(fn (Model $record
                                    ) => "{$record->name} - S/. {$record->unit_price} - Stock: {$record->quantity}")
                                    ->distinct()
                                    ->disableOptionsWhenSelectedInSiblingRepeaterItems()
                                    ->required(),
                                TextInput::make('quantity')
                                    ->label(__('Quantity'))
                                    ->integer()
                                    ->lte(function (Get $get) {

                                        return Accessory::find($get('accessory_id'))->quantity ?? 0;
                                    }, true)
                                    ->afterStateUpdated(function (HasForms $livewire, TextInput $component) {
                                        $livewire->validateOnly($component->getStatePath());
                                    })
                                    ->required(),
                            ])
                            ->live()
                            ->afterStateUpdated(function (Set $set, Get $get) {
                                self::updatePriceCost($get, $set);
                            })
                            ->grid(2),
                    ])
                    ->columns(1),
                TextInput::make('cost_price')
                    ->label(__('Cost'))
                    ->numeric()
                    ->disabled()
                    ->dehydrated(),
                TextInput::make('price')
                    ->label(__('Price'))
                    ->numeric()
                    ->extraInputAttributes(['min' => 0])
                    ->gt(function (Get $get) {
                        return $get('cost_price');
                    }, true)
                    ->live()
                    ->afterStateUpdated(function (HasForms $livewire, TextInput $component) {
                        $livewire->validateOnly($component->getStatePath());
                    })
                    ->required(),
                TextInput::make('discount')
                    ->label(__('Discount'))
                    ->numeric()
                    ->suffix('%')
                    ->lt(function (Get $get) {
                        if (empty($get('price')) || empty($get('cost_price')) || empty($get('price'))) {
                            return true;
                        }

                        return (((float) $get('price') - (float) $get('cost_price')) / (float) $get('price')) * 100;
                    }, true)
                    ->live()
                    ->afterStateUpdated(function (HasForms $livewire, TextInput $component) {
                        $livewire->validateOnly($component->getStatePath());
                    })
                    ->nullable(),
                TextInput::make('sku')
                    ->label(__('SKU'))
                    ->disabled()
                    ->formatStateUsing(fn (?string $state): string => $state ?? strtoupper(Str::random(10)))
                    ->dehydrated(),
                TextInput::make('stock')
                    ->label(__('Stock'))
                    ->integer()
                    ->required(),
                Select::make('status')
                    ->label(__('Status'))
                    ->options([
                        'active' => 'Activo',
                        'inactive' => 'Inactivo',
                    ])
                    ->required(),
                SpatieMediaLibraryFileUpload::make('image')
                    ->label(__('Image'))
                    ->multiple()
                    ->image(),
            ]);
    }

    public static function updatePriceCost(Get $get, Set $set): void
    {
        $material = Material::find($get('material_id'));
        $materialPrice = ($material->unit_price ?? 0) * (empty($get('material_weight')) ? 0 : $get('material_weight'));
        $price = collect($get('productAccessories'))->reduce(function ($carry, $accessory) {
            if (is_null($accessory['accessory_id']) && is_null($accessory['quantity'])) {
                return $carry;
            }

            $accessoryModel = Accessory::find($accessory['accessory_id']);
            $carry += (float) $accessoryModel->unit_price * (float) $accessory['quantity'];

            return $carry;
        }, 0);
        $set('cost_price', $price + $materialPrice);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                SpatieMediaLibraryImageColumn::make('image')
                    ->label(__('Image')),
                TextColumn::make('name')
                    ->label(__('Name'))
                    ->searchable(),
                TextColumn::make('category.name')
                    ->label(__('Category'))
                    ->searchable(),
                TextColumn::make('material.name')
                    ->label(__('Material'))
                    ->searchable(),
                TextColumn::make('accessories.name')
                    ->label(__('Accessories'))
                    ->listWithLineBreaks()
                    ->bulleted(),
                TextColumn::make('cost_price')
                    ->label(__('Cost'))
                    ->numeric()
                    ->formatStateUsing(fn (string $state) => Number::currency($state, in: 'S/.')),
                TextColumn::make('price')
                    ->label(__('Price'))
                    ->numeric()
                    ->formatStateUsing(fn (string $state) => Number::currency($state, in: 'S/.')),
                TextColumn::make('discount')
                    ->label(__('Discount')),
                TextColumn::make('sku')
                    ->label(__('SKU')),
                TextColumn::make('stock')
                    ->label(__('Stock')),
                TextColumn::make('status')
                    ->label(__('Status'))
                    ->formatStateUsing(fn ($state): string => match ($state) {
                        'active' => 'Activo',
                        'inactive' => 'Inactivo',
                        default => $state,
                    })
                    ->alignCenter(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProducts::route('/'),
            'create' => Pages\CreateProduct::route('/create'),
            'edit' => Pages\EditProduct::route('/{record}/edit'),
        ];
    }

    public static function getNavigationLabel(): string
    {
        return __('Products');
    }

    public static function getBreadcrumb(): string
    {
        return __('Products');
    }

    public static function canEdit(Model $record): bool
    {
        return auth()->user()->hasRole('super_admin') || $record->created_at->isToday();
    }
}
