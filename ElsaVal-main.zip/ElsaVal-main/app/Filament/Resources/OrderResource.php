<?php

namespace App\Filament\Resources;

use App\Enums\OrderStatus;
use App\Filament\Resources\OrderResource\Pages;
use App\Models\Order;
use App\Models\OrderProduct;
use App\Models\Product;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Forms\Get;
use Filament\Forms\Set;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Number;

class OrderResource extends Resource
{
    protected static ?string $model = Order::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Select::make('client_id')
                    ->label(__('Client'))
                    ->relationship('client', 'name', modifyQueryUsing: fn (Builder $query) => $query->with('user'))
                    ->getOptionLabelFromRecordUsing(fn (Model $record) => $record?->user->name)
                    ->native(false)
                    ->searchable()
                    ->preload()
                    ->columnSpan(2)
                    ->required(),
                Select::make('status')
                    ->label(__('Status'))
                    ->options(OrderStatus::class)
                    ->columnSpan(2)
                    ->required(),
                Section::make()
                    ->schema([
                        Repeater::make('orderProducts')
                            ->label(__('Products'))
                            ->relationship()
                            ->schema([
                                Select::make('product_id')
                                    ->label(__('Product'))
                                    ->relationship('product', 'name')
                                    ->searchable()
                                    ->preload()
                                    ->live()
                                    ->afterStateUpdated(function (Set $set, $state) {
                                        $set('unit_price', Product::find($state)?->price ?? 0);
                                    })
                                    ->distinct()
                                    ->disableOptionsWhenSelectedInSiblingRepeaterItems()
                                    ->columnSpan(6)
                                    ->required(),
                                TextInput::make('unit_price')
                                    ->label(__('Unit Price'))
                                    ->numeric()
                                    ->dehydrated(false)
                                    ->columnSpan(2)
                                    ->disabled()
                                    ->dehydrated()
                                    ->required(),
                                TextInput::make('quantity')
                                    ->label(__('Quantity'))
                                    ->integer()
                                    ->live()
                                    ->afterStateUpdated(function (Set $set, Get $get, $state) {
                                        $set('total_price', (float) $get('unit_price') * (float) $state);
                                        $set('../../subtotal_price', collect($get('../../orderProducts'))->sum('total_price'));
                                        $set('../../total_price', (float) $get('../../subtotal_price') + (float) $get('../../delivery_price') - ((float) $get('../../subtotal_price') * ((float) $get('../../discount') / 100)));
                                    })
                                    ->columnSpan(2)
                                    ->required(),
                                TextInput::make('total_price')
                                    ->label(__('Total Price'))
                                    ->numeric()
                                    ->disabled()
                                    ->dehydrated()
                                    ->columnSpan(2)
                                    ->required(),
                            ])
                            ->columns(12)
                            ->live(),
                    ]),
                TextInput::make('subtotal_price')
                    ->label(__('Subtotal Price'))
                    ->numeric()
                    ->disabled()
                    ->dehydrated()
                    ->required(),
                TextInput::make('delivery_price')
                    ->label(__('Delivery Price'))
                    ->numeric()
                    ->live()
                    ->afterStateUpdated(function (Set $set, Get $get, $state) {
                        $set('total_price', (float) $get('subtotal_price') + (float) $state - ((float) $get('subtotal_price') * ((float) $get('discount') / 100)));
                    })
                    ->nullable(),
                TextInput::make('discount')
                    ->label(__('Discount'))
                    ->numeric()
                    ->suffix('%')
                    ->live()
                    ->afterStateUpdated(function (Set $set, Get $get, $state) {
                        $set('total_price', (float) $get('subtotal_price') + (float) $get('delivery_price') - ((float) $get('subtotal_price') * ((float) $state / 100)));
                    })
                    ->nullable(),
                TextInput::make('total_price')
                    ->label(__('Total Price'))
                    ->numeric()
                    ->disabled()
                    ->dehydrated()
                    ->required(),
                Textarea::make('street_address')
                    ->label(__('Street Address'))
                    ->columnSpan(4)
                    ->nullable(),
            ])->columns(4);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('client.user.name')
                    ->label(__('Name'))
                    ->searchable()
                    ->toggleable(),
                TextColumn::make('status')
                    ->label(__('Status'))
                    ->badge()
                    ->toggleable(),
                TextColumn::make('subtotal_price')
                    ->label(__('Subtotal Price'))
                    ->formatStateUsing(fn (string $state) => Number::currency($state, in: 'S/.'))
                    ->toggleable(),
                TextColumn::make('delivery_price')
                    ->label(__('Delivery Price'))
                    ->formatStateUsing(fn (string $state) => Number::currency($state, in: 'S/.'))
                    ->toggleable(),
                TextColumn::make('discount')
                    ->label(__('Discount'))
                    ->formatStateUsing(fn (string $state) => $state.'%')
                    ->toggleable(),
                TextColumn::make('total_price')
                    ->label(__('Total Price'))
                    ->formatStateUsing(fn (string $state) => Number::currency($state, in: 'S/.'))
                    ->toggleable(),
                TextColumn::make('street_address')
                    ->label(__('Street Address'))
                    ->toggleable(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\Action::make('no_stock')
                    ->label(__('No stock'))
                    ->color('danger')
                    ->modalHeading('Productos sin Stock')
                    ->modalDescription('Los siguientes productos no tienen stock suficiente para completar la orden.')
                    ->modalContent(function (Order $record) {
                        return view('products-out-of-stock', ['order' => $record]);
                    })
                    ->visible(function (Order $record) {
                        return $record->orderProducts->contains(function (OrderProduct $orderProduct) {
                            return $orderProduct->quantity > $orderProduct->product->stock;
                        });
                    }),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->with(['client.user', 'orderProducts.product']);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListOrders::route('/'),
            'create' => Pages\CreateOrder::route('/create'),
            'edit' => Pages\EditOrder::route('/{record}/edit'),
        ];
    }

    public static function getNavigationLabel(): string
    {
        return __('Orders');
    }

    public static function getBreadcrumb(): string
    {
        return __('Orders');
    }

    public static function canEdit(Model $record): bool
    {
        return auth()->user()->hasRole('super_admin') || $record->created_at->isToday();
    }
}
