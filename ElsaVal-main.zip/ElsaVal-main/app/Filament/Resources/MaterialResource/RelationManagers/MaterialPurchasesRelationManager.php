<?php

namespace App\Filament\Resources\MaterialResource\RelationManagers;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Model;

class MaterialPurchasesRelationManager extends RelationManager
{
    protected static string $relationship = 'materialPurchases';

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('quantity')
                    ->label(__('Quantity (gr.)'))
                    ->numeric()
                    ->integer()
                    ->required(),
                TextInput::make('total_price')
                    ->label(__('Total Price'))
                    ->numeric()
                    ->inputMode('decimal')
                    ->minValue(0.01)
                    ->required(),
                Select::make('provider_id')
                    ->label(__('Provider'))
                    ->relationship('provider', 'name')
                    ->required(),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('material_id')
            ->columns([
                Tables\Columns\TextColumn::make('quantity')
                    ->label(__('Quantity (gr.)')),
                Tables\Columns\TextColumn::make('total_price')
                    ->label(__('Total Price')),
                Tables\Columns\TextColumn::make('provider.name')
                    ->label(__('Provider')),
                Tables\Columns\TextColumn::make('created_at')
                    ->label(__('Created At'))
                    ->date('d/m/Y h:i:s A'),
            ])
            ->filters([
                //
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()
                    ->after(function (Model $record) {
                        $record->material()->increment('quantity', $record->quantity);
                        $record->material()->update([
                            'unit_price' => $record->material->materialPurchases()->sum('total_price')
                                / $record->material->materialPurchases()->sum('quantity'),
                        ]);
                    }),
            ])
            ->actions([
                Tables\Actions\EditAction::make()
                    ->visible(fn (Model $record) => $record->created_at->isToday())
                    ->before(function (EditAction $action, Model $record, array $data) {
                        $newQuantity = $data['quantity'] - $record->quantity;
                        if ($record->material->quantity + $newQuantity <= 0) {
                            Notification::make()
                                ->warning()
                                ->title('Acción no permitida')
                                ->body('La cantidad de materiales no puede ser menor o igual a 0.')
                                ->send();

                            $action->halt();
                        }
                    })
                    ->using(function (Model $record, array $data): Model {
                        $newQuantity = $data['quantity'] - $record->quantity;
                        $record->update(['quantity' => $data['quantity']]);
                        $record->material()->increment('quantity', $newQuantity);

                        return $record;
                    }),
                Tables\Actions\DeleteAction::make()
                    ->after(function (Model $record) {
                        $record->material()->decrement('quantity', $record->quantity);
                        $record->material()->update([
                            'unit_price' => $record->material->materialPurchases()->sum('total_price')
                                / $record->material->materialPurchases()->sum('quantity'),
                        ]);
                    }),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])->defaultSort('created_at', 'desc');
    }
}
