<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class Material extends Model implements HasMedia
{
    use InteractsWithMedia;

    public function priceHistories(): MorphMany
    {
        return $this->morphMany(PriceHistory::class, 'model');
    }

    public function materialPurchases(): HasMany
    {
        return $this->hasMany(MaterialPurchase::class);
    }

    public function latestPurchase(): HasOne
    {
        return $this->hasOne(MaterialPurchase::class)->latestOfMany();
    }
}
