<?php

namespace App\Models;

use App\Observers\AccessoryProductObserver;
use Illuminate\Database\Eloquent\Attributes\ObservedBy;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\Pivot;

#[ObservedBy(AccessoryProductObserver::class)]
class AccessoryProduct extends Pivot
{
    public function accessory(): BelongsTo
    {
        return $this->belongsTo(Accessory::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
