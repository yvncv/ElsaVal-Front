<?php

if (! function_exists('generateIdentifier')) {
    function generateIdentifier($prefix, $model, $length = 5): string
    {
        $lastId = $model::max('id') ?? 0;

        return $prefix.str_pad($lastId + 1, $length, '0', STR_PAD_LEFT);
    }
}
