<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call(ShieldSeeder::class);

        User::factory()->create([
            'name' => 'Administrador',
            'email' => 'admin@test.com',
            'is_active' => true,
        ])->assignRole(Role::first());

        User::factory()->create([
            'name' => 'Operario',
            'email' => 'operario@test.com',
            'is_active' => true,
        ])->assignRole(Role::findByName('operario'));

        User::factory()->create([
            'name' => 'Cliente 1',
            'email' => 'cliente@test.com',
            'is_active' => true,
        ])->assignRole(Role::findByName('Cliente'));
    }
}
