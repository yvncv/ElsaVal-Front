<?php

use App\Models\Client;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('identifier')->unique();
            $table->uuid();
            $table->foreignIdFor(Client::class)->constrained();
            $table->decimal('subtotal_price');
            $table->decimal('delivery_price')->nullable();
            $table->decimal('discount')->nullable();
            $table->decimal('total_price');
            $table->string('street_address')->nullable();
            $table->string('status');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
