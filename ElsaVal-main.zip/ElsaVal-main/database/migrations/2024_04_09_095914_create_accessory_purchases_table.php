<?php

use App\Models\Accessory;
use App\Models\Provider;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('accessory_purchases', function (Blueprint $table) {
            $table->id();
            $table->foreignIdFor(Accessory::class)->constrained();
            $table->integer('quantity');
            $table->decimal('total_price');
            $table->foreignIdFor(Provider::class)->constrained();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('price_histories');
    }
};
