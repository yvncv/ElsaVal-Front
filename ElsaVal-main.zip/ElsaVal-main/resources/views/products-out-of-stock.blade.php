<div>
    <ul class="list-disc list-inside">
        @foreach($order->orderProducts as $orderProduct)
            @if($orderProduct->quantity > $orderProduct->product->stock)
                <li>The product {{ $orderProduct->product->name }} is out of stock.</li>
            @endif
        @endforeach
    </ul>
</div>
