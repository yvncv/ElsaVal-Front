<?php

use App\Http\Controllers\Api\CartController;
use App\Http\Controllers\Api\CartItemController;
use App\Http\Resources\CategoryResource;
use App\Http\Resources\ClientResource;
use App\Http\Resources\OrderResource;
use App\Http\Resources\ProductResource;
use App\Models\Category;
use App\Models\Client;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Validation\Rule;
use Laravel\Fortify\Http\Controllers\AuthenticatedSessionController;
use Laravel\Fortify\Http\Controllers\RegisteredUserController;

Route::post('/login', [AuthenticatedSessionController::class, 'store']);
Route::post('/register', [RegisteredUserController::class, 'store']);

Route::middleware('auth:sanctum')->group(function () {
    Route::get('/user', function (Request $request) {
        return $request->user();
    });

    Route::post('/logout', [AuthenticatedSessionController::class, 'destroy']);

    Route::resource('carts', CartController::class)->only(['store', 'destroy']);
    Route::resource('cart-items', CartItemController::class)->only(['store', 'update', 'destroy']);
});

Route::prefix('elsaval')->group(function () {
    Route::get('/products', fn (Request $request) => ProductResource::collection(
        Product::query()
            ->when($request->has('category_id'), fn ($query) => $query->where('category_id', $request->get('category_id')))
            ->with(['category', 'material'])
            ->get()
    ));

    Route::get('/products/{product}',
        fn (Product $product) => new ProductResource($product->load(['category', 'material'])));

    Route::get('/categories', fn (Category $category) => CategoryResource::collection(Category::all()));
    Route::get('/categories/{category}', fn (Category $category) => new CategoryResource($category));

    Route::get('/clients', fn (Request $request) => ClientResource::collection(
        Client::query()
            ->when($request->has('name'), fn ($query) => $query->where('name', 'like', "%{$request->get('name')}%"))
            ->with('user')
            ->get()
    ));
    Route::post('/clients', function (Request $request) {
        $validated = $request->validate([
            'name' => 'required|string',
            'email' => ['required', 'email', Rule::unique('users', 'email')],
            'password' => 'required|string',
        ]);

        $validated['password'] = bcrypt($validated['password']);

        $user = User::create($validated);
        $user->client()->create();

        return response()->json(['message' => 'Cliente creado correctamente']);
    });

    Route::get('/clients/{client}', function (Client $client) {
        return new ClientResource($client->load('user'));
    });

    Route::put('/clients/{client}', function (Request $request, Client $client) {
        $validated = $request->validate([
            'name' => 'required|string',
            'email' => ['required', 'email', Rule::unique('users', 'email')->ignore($client->user->id)],
            'password' => 'nullable|string',
        ]);

        if (isset($validated['password'])) {
            $validated['password'] = bcrypt($validated['password']);
        }

        $client->user->update($validated);

        return response()->json(['message' => 'Cliente actualizado correctamente']);
    });

    Route::put('/products/{product}', function (Request $request, Product $product) {
        $validated = $request->validate([
            'stock' => 'required|numeric',
        ]);

        $product->update($validated);

        return response()->json(['message' => 'Producto actualizado correctamente']);
    });

    Route::post('/orders', function (Request $request) {
        $validated = $request->validate([
            'client_id' => 'required|exists:clients,id',
            'status' => 'required|string',
            'delivery_price' => 'nullable|numeric',
            'discount' => 'nullable|numeric',
            'street_address' => 'required|string',
            'order_products' => 'required|array',
            'order_products.*.product_id' => 'required|exists:products,id',
            'order_products.*.quantity' => 'required|numeric',
        ]);

        $order = Order::create([
            'client_id' => $validated['client_id'],
            'status' => $validated['status'],
            'street_address' => $validated['street_address'],
            'subtotal_price' => 0,
            'total_price' => 0,
        ]);

        $subtotalPrice = 0;
        foreach ($validated['order_products'] as $orderProduct) {
            $product = Product::find($orderProduct['product_id']);

            $order->products()->attach($product->id, [
                'unit_price' => $product->price,
                'quantity' => $orderProduct['quantity'],
                'total_price' => $product->price * $orderProduct['quantity'],
            ]);

            $subtotalPrice += $product->price * $orderProduct['quantity'];
        }

        $totalPrice = $subtotalPrice;

        if ($validated['discount']) {
            $totalPrice -= ($validated['discount'] / 100) * $totalPrice;
        }

        if ($validated['delivery_price']) {
            $totalPrice += $validated['delivery_price'];
        }

        $order->update([
            'subtotal_price' => $subtotalPrice,
            'total_price' => $totalPrice,
        ]);

        return response()->json(['message' => 'Orden creada correctamente']);
    });

    Route::get('/orders', function (Request $request) {
        $validated = $request->validate([
            'client_id' => 'nullable|exists:clients,id',
        ]);

        $orders = Order::query()
            ->when($request->has('client_id'), fn ($query) => $query->where('client_id', $validated['client_id']))
            ->get();

        return OrderResource::collection($orders->load(['client.user', 'orderProducts.product']));
    });

    Route::get('/orders/{order}', fn (Order $order) => new OrderResource($order->load(['client.user', 'orderProducts.product'])));
});
